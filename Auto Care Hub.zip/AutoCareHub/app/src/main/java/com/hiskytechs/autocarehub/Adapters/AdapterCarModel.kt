package com.hiskytechs.autocarehub.Adapters

class AdapterCarModel {
}