package com.hiskytechs.autocarehub.models

data class ModelNews(
    val imageUrl: String = "",
    val title: String = "",
    val description: String = ""
)
