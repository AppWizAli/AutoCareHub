package com.hiskytechs.autocarehub.Adapters

class AdapterInquiryList {
}