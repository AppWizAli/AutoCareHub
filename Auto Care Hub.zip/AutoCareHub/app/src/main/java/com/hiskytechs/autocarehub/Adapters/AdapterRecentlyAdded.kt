package com.hiskytechs.autocarehub.Adapters

class AdapterRecentlyAdded {
}